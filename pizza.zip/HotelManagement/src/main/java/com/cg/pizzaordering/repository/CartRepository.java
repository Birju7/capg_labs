//package com.cg.pizzaordering.repository;
//
//import org.springframework.data.jpa.repository.JpaRepository;
//
//import com.cg.pizzaordering.dto.Cart;
//
//public interface CartRepository extends JpaRepository<Cart, Long> {
//
//}

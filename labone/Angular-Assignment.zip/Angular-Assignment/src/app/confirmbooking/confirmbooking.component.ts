// import { Component, OnInit } from '@angular/core';
// import { ActivatedRoute, Router } from "@angular/router";

// @Component({
//   selector: 'app-confirmbooking',
//   templateUrl: './confirmbooking.component.html'
// })
// export class ConfirmbookingComponent implements OnInit {

//   constructor(private route: ActivatedRoute, private router:Router) { }
// pizza:any;
//   ngOnInit() {

//   }

// }

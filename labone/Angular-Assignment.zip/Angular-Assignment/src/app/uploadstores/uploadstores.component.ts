import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-uploadstores',
  templateUrl: './uploadstores.component.html',
  
})
export class UploadstoresComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

export class Pizza{
    //createdBy: any
// createdDate:any
// deleteFlag: any
// modifiedBy: any
// modifiedDate:any
pizzaId: number
pizzaName: string
pizzaCost: number
pizzaType: string
pizzaSize: string
pizzaDescription: string
    }
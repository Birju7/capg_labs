export class City{
    cityId:number;
    cityName:string;
    }
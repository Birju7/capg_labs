export class Customer{
    userId:any;
    username:any;
    emailId:any;
    userMobile:any;
    firstName:any;
    lastName:any;
    password:any;
    role:any;
    pizza:any;
}
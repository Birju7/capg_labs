import { Pizza } from "./app.pizza";

export class Store{
//    createdBy: any;
// createdDate: any;
// deleteFlag: any;
storeAddress: string;
storeId: number;
storeName: string;
storePhoneNumber: string;
// modifiedBy: any;
// modifiedDate: any;
pizzaist:Pizza[];
}
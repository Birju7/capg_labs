import { Room } from "./app.room";

export class Booking{
    bookingId:number;
    checkIn:Date;
    checkOut:Date;
    cityName:string;
    hotelName:string;
    hotelAddress:string;
    hotelPhoneno:string;
    hotelRating:number;
    room:Room;

    }
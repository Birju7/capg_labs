export class Room{
    //createdBy: any
// createdDate:any
// deleteFlag: any
// modifiedBy: any
// modifiedDate:any
roomId: number
roomNumber: string
roomRent: number
roomType: string
    }